// use mongoose
const mongoose = require('mongoose')
const mongoDB = 'mongodb+srv://pirjomurefullstack:<salasana>@fullstack.xawpbhe.mongodb.net/?retryWrites=true&w=majority'

// connect mongodb
mongoose.connect(mongoDB, {useNewUrlParser: true, useUnifiedTopology: true})
const db = mongoose.connection

// check connection - ok or error
db.on('error', console.error.bind(console, 'connection error:'))
db.once('open', function() {
  console.log("Database test connected")
})

// schema for students
const studentSchema = new mongoose.Schema({
    student_id: Number,
    lastname: String,
    firstname: String,
    birthdate: Date,
    eyecolor: String,
    incomes: Number,
    taxrate: Number,
    hometown: {
      cityname: String,
      population: Number
    },
    courses: [
      {
        coursename: String,
        credits: Number,
        date_created: Date,
        grade: Number,
      }
    ]
  })

// schema for cities
const citySchema = new mongoose.Schema({
    cityname: String,
    population: Number
  })

// schema for courses
const courseSchema = new mongoose.Schema({
    coursename: String,
    credits: Number
  })

// new models
const Student = mongoose.model('Student', studentSchema, 'students')
const City = mongoose.model('City', citySchema, 'cities')
const Course = mongoose.model('Course', courseSchema, 'courses')

const city_data = [
    ['Turku', 190000],
    ['Tampere', 230000],
    ['Lahti', 120000]
]

const course_data = [
    ['Ohjelmointi', 5],
    ['Tietokannat', 4],
    ['Ruotsi', 3]
]

const grade_data = [
    [2001, 0, '2018-11-11', 5],
    [2001, 1, '2019-11-11', 5],
    [2001, 2, '2020-11-11', 5],
    [2002, 0, '2018-11-11', 4],
    [2002, 1, '2019-11-11', 4],
    [2002, 2, '2020-11-11', 4],
    [2003, 0, '2018-11-11', 3],
    [2003, 1, '2019-11-11', 4],
    [2003, 2, '2020-11-11', 4],
    [2004, 2, '2020-11-11', 1],
    [2005, 2, '2020-11-11', 1],
    [2006, 0, '2018-11-11', 2],
    [2006, 1, '2019-11-11', 2],
    [2006, 2, '2020-11-11', 3],
    [2007, 0, '2018-11-11', 3],
    [2007, 1, '2019-11-11', 4],
    [2008, 0, '2018-11-11', 4],
    [2008, 1, '2019-11-11', 5]
]

const student_data = [
    [2001, 'Guru',     'Ken',   '2001-11-11', 'Ruskea',  12010.12, 5.1, 0],
    [2002, 'Saurus',   'Tino',  '2002-11-11', 'Ruskea',  14010.22, 6.2, 0],
    [2003, 'Tiainen',  'Sini',  '2003-11-11', 'Sininen', 16010.32, 7.3, 0],
    [2004, 'Vainio',   'Vilja', '2004-11-11', 'Sininen', 0.00,     0.0, 2],
    [2005, 'Vainio',   'Elo',   '2005-11-11', 'Sininen', 0.00,     0.0, 2],
    [2006, 'Rahainen', 'Muu',   '2006-11-11', 'Harmaa',  13010.12, 5.8, 1],
    [2007, 'Alainen',  'Kim',   '2007-11-11',  null,     18010.12, 8.8, 1],
    [2008, 'Ana',      'Ruut',  '2008-11-11',  null,     20010.12, 9.9, null]
]

for (var i = 0; i < student_data.length; i++) {

    //create courses for the students
    let courses = []

    for (let grade of grade_data) {
        if (grade[0] == student_data[i][0]) {
            courses.push({
                coursename: course_data[grade[1]][0],
                credits: course_data[grade[1]][1],
                date_created: grade[2],
                grade: grade[3],
            })
        }
    }

    if (student_data[i][7]) {
        hometown_index = student_data[i][7]
        var hometown = {
            cityname: city_data[hometown_index][0],
            population: city_data[hometown_index][1]
          }
    }

    //create a new student
    const student = new Student({
        student_id: student_data[i][0],
        lastname: student_data[i][1],
        firstname: student_data[i][2],
        birthdate: student_data[i][3],
        eyecolor: student_data[i][4],
        incomes: student_data[i][5],
        taxrate: student_data[i][6],
        hometown: hometown,
        courses: courses
      })

    //save to db
    const savedStudent = student.save()
}

for (let i = 0; i < city_data.length; i++) {
    const city = new City({
        cityname: city_data[i][0],
        population: city_data[i][1]
    })

    const savedCity = city.save()
}

for (let i = 0; i < course_data.length; i++) {
    const course = new Course({
        coursename: course_data[i][0],
        credits: course_data[i][1]
    })

    const savedCourse = course.save()
}
