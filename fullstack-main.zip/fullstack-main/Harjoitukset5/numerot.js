const numbers=[1,3,4,6,10,12];

const summa= numbers.reduce(function(a, b) { return a + b; }, 0);

module.exports = {
   summa
}