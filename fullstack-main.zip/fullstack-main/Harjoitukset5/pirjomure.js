
getName = () => "Pirjo Mure"
getLocation = () => "Laukaa"
const birthdate = "30.05.1980"

module.exports = {
    getName, getLocation, birthdate
}