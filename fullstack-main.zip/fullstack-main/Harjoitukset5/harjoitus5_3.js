//4/4pistettä
console.log("Reading file and calculate a sum...")

const luvut = require('./numerot')

const summa=luvut.summa

console.log(`Sum is: ${summa}`)
