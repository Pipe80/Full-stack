# Fullstack

Mure Pirjo N5589

Ratkaisut: https://student.labranet.jamk.fi/~N5589/fullstack_harjoitukset/


Harjoitustehtäväpisteet:   121/189

Kaikki tarjolla olleet harjoitustehtäväpisteet:   189

121/189 = > 64 %



